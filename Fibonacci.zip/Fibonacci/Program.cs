﻿namespace Fibonacci
{
    public class Program
    {
        private static void Main(string[] args)
        {
            int fibonacci_limit = 21;
            int starting_number = 0;
            int second_number = 1;

            Console.Write(starting_number + " " + second_number + " ");

            while (true)
            {
                int next = starting_number + second_number;
                if (next > fibonacci_limit)
                {
                    break;
                }
                Console.Write(next + " ");
                starting_number = second_number;
                second_number = next;
            }
        }
    }
}